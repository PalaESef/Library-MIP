package org.example.models;

public class Borrowable {
}
